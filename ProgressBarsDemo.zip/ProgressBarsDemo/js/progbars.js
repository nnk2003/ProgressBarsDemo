// callback function 
var xhr = new XMLHttpRequest();
var limtValue = "";
var data = ""
xhr.onreadystatechange = function() {
	if (this.readyState == 4 && this.status == 200) {

		data = JSON.parse(this.responseText);
		for (var count = 0; count < data.buttons.length; count++) {

			var button = document.createElement("BUTTON");
			var buttonsBlock = document.getElementById("buttons");
			buttons.appendChild(button);
			button.setAttribute("class", "cmybar meter animate");

			button.innerHTML = data.buttons[count];
			button.setAttribute("value", data.buttons[count]);
			button.setAttribute("id", "button" + count);
			button.setAttribute("class", 'Buttons');
			button.addEventListener('click', function() {
				addwidth(this.value);
			});

		}

		limtValue = data.limit;

		// progress bars

		for (var i = 0; i < data.bars.length; i++) {
			var progress = document.createElement("div");
			var cont = document.getElementById("content");
			cont.appendChild(progress);
			progress.setAttribute("class", "cmyprogress");
			progress.setAttribute("id", "progress" + i);

			var bar = document.createElement("div");
			progress.appendChild(bar);
			bar.setAttribute("class", "cmybar meter animate");
			bar.setAttribute("id", "Buttons" + i);

			var barWidth = ((data.bars[i] / data.limit) * 100);
			bar.style.width = parseFloat(barWidth) + "%";

			var spanEle = document.createElement("span");
			bar.appendChild(spanEle);
			spanEle.setAttribute("id", "spanEle" + i);
			var spanEle2 = document.createElement("span");
			spanEle2.setAttribute("id", "spanEle2" + i);
			spanEle.appendChild(spanEle2);

			var lb = document.createElement("label");
			bar.appendChild(lb);
			lb.setAttribute("class", "clabel");
			lb.setAttribute("id", "label" + i);
			lb.innerHTML = (barWidth).toFixed(2) + "%";

		}

		var ddl = document.createElement("select");
		var but = document.getElementById("buttons");
		but.appendChild(ddl);
		ddl.setAttribute("id", "ddselect");

		// dropdown based on bars length
		for (var i = 0; i < data.bars.length; i++) {
			var opt = document.createElement("option");
			ddl.appendChild(opt);
			opt.setAttribute("id", "ddl" + i);
			opt.setAttribute("value", i);
			opt.innerHTML = "Progress Bar " + (1 + i);
		}

		var x = document.getElementById("loader");
		x.style.display = "none";

		var reset_button = document.createElement("BUTTON");
		var buttonsBlock = document.getElementById("content");
		// 				reset_button.appendChild(buttonsBlock);
		buttonsBlock.appendChild(reset_button);
		reset_button.setAttribute("class", "reset");

		reset_button.innerHTML = "RESET";	
		reset_button.addEventListener('click', function() {
			resetFn(this.value);
		});

	}

};

function resetFn(value) {
	//alert("asdasdas");

	location.reload();
}
// filling bar by passing value
function addwidth(value) {
	// progress bar selection based on dropdown value seletion

	var v = parseInt(document.getElementById("ddselect").value);
	var a = document.getElementById("label" + v).innerHTML;

	// add current value of bar + button current value of selected bar
	var newBarPercentage = (((value / data.limit) * 100) + parseInt(a));
	value = parseInt(value) + parseInt(a);

	// change the color to red if the progress bar value > 100 and above
	if (newBarPercentage >= 100) {

		document.getElementById("spanEle" + v).style.backgroundColor = "red";
		document.getElementById("Buttons" + v).style.width = "100%";
		document.getElementById("label" + v).innerHTML = newBarPercentage
				.toFixed(2)
				+ "%";
		//meter 
	}
	//if value is less than 100 and greater than 0 than select same green color;
	else if (value <= parseInt(limtValue) && value > 0) {

		document.getElementById("spanEle" + v).style.backgroundColor = "rgb(43,194,83)";
		document.getElementById("Buttons" + v).style.width = newBarPercentage
				.toFixed(2)
				+ "%";

		document.getElementById("label" + v).innerHTML = newBarPercentage
				.toFixed(2)
				+ "%";
	}
	// if value is <= to 0 than set value and with of bar equal to 0
	else if (value <= 0) {
		document.getElementById("Buttons" + v).style.width = "0%";
		document.getElementById("label" + v).innerHTML = "0%";
		document.getElementById("Buttons" + v).style.background = "transparent";

	}
}

// sending request to sever 
xhr.open("GET", "http://pb-api.herokuapp.com/bars");
xhr.send();